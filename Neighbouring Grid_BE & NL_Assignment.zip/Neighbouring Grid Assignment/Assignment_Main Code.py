"""
#Assignment- Neighbouring Grids combines Python programming, CIM-XML modelling and parsing and
finally model building using Pandapower.Merge Belgium(BE) and Netherlands(NL) MicroGrid configurations, 
walking XML trees, identifying missing resource IDs, and plotting the resulting merged grid.

@author: Amritha Jayan and Sarika Vaiyapuri Gunassekaran

"""
import xml.etree.ElementTree as ET
import pandapower as pp
import pandapower.plotting as plot

# Parse the XML files for different equipment configurations
tree_BE_EQ=ET.parse("MicroGridTestConfiguration_T4_BE_EQ_V2.xml")
tree_BE_SSH=ET.parse("MicroGridTestConfiguration_T4_BE_SSH_V2.xml")
tree_NL_EQ=ET.parse("MicroGridTestConfiguration_T4_NL_EQ_V2.xml")
tree_NL_SSH=ET.parse("MicroGridTestConfiguration_T4_NL_SSH_V2.xml")
# Get the root elements for each XML tree
root_BE_EQ = tree_BE_EQ.getroot()
root_BE_SSH = tree_BE_SSH.getroot()
root_NL_EQ = tree_NL_EQ.getroot()
root_NL_SSH = tree_NL_SSH.getroot()

# Define XML namespaces for CIM standard
cim = "{http://iec.ch/TC57/2013/CIM-schema-cim16#}"
md = "{http://iec.ch/TC57/61970-552/ModelDescription/1#}"
rdf = "{http://www.w3.org/1999/02/22-rdf-syntax-ns#}"

# Define a function to extract grid topology
def extract_grid_topology(root_EQ, root_SSH):

    # Import the required classes from their respective modules
    from Class.ACLineSegment import ACLineSegment
    from Class.BusbarSection import BusbarSection
    from Class.Breaker import Breaker
    from Class.PowerTransformer import PowerTransformer
    from Class.PowerTransformerEnd import PowerTransformerEnd
    from Class.EnergyConsumer import EnergyConsumer   
    from Class.GeneratingUnit import GeneratingUnit
    from Class.SynchronousMachine import SynchronousMachine
    from Class.VoltageLevel import VoltageLevel
    from Class.ConnectivityNode import ConnectivityNode
    from Class.Terminal import Terminal

    # Initialize empty lists to store the extracted information from the EQ XML files
    AC_line_segment_list = []
    breaker_list = []
    busbar_section_list = []
    connectivity_node_list = []
    energy_consumer_list = []
    generating_unit_list = []
    power_transformer_list = []
    power_transformer_end_list = []
    synchronous_machine_list = []
    terminal_list = []
    voltage_level_list = []

    #Forming the list of AC Line segment
    for AC_line_segment_xml in root_EQ.iter(cim+'ACLineSegment'):
        AC_line_segment_list.append(ACLineSegment(AC_line_segment_xml.get(rdf+'ID'),
        AC_line_segment_xml.find(cim+'IdentifiedObject.name').text,
        AC_line_segment_xml.find(cim+'Equipment.EquipmentContainer').get(rdf+'resource').replace('#', ''),
        AC_line_segment_xml.find(cim+'ACLineSegment.r').text, 
        AC_line_segment_xml.find(cim+'ACLineSegment.x').text, 
        AC_line_segment_xml.find(cim+'ACLineSegment.bch').text,
        AC_line_segment_xml.find(cim+'Conductor.length').text,
        AC_line_segment_xml.find(cim+'ACLineSegment.gch').text,
        AC_line_segment_xml.find(cim+'ConductingEquipment.BaseVoltage').get(rdf+'resource'),  
        AC_line_segment_xml.find(cim+"ACLineSegment.r0"), 
        AC_line_segment_xml.find(cim+"ACLineSegment.x0"), 
        AC_line_segment_xml.find(cim+"ACLineSegment.b0ch"),
        AC_line_segment_xml.find(cim+"ACLineSegment.g0ch")))

    # Forming the list of Breakers
    for breaker_xml in root_EQ.iter(cim+'Breaker'):
        breaker_list.append(Breaker(breaker_xml.get(rdf+'ID'), 
        breaker_xml.find(cim+'IdentifiedObject.name').text,
        breaker_xml.find(cim+'Equipment.EquipmentContainer').get(rdf+'resource').replace('#', ''),
        breaker_xml.find(cim+'Switch.normalOpen').text))    

    #Forming the list of Bus Bar sections
    for busbar_section_xml in root_EQ.iter(cim+'BusbarSection'):
        busbar_section_list.append(BusbarSection(busbar_section_xml.get(rdf+'ID'), 
        busbar_section_xml.find(cim+'IdentifiedObject.name').text, 
        busbar_section_xml.find(cim+'Equipment.EquipmentContainer').get(rdf+'resource').replace('#', '')))

    #Forming the list of Connectivity nodes
    for connectivity_node_xml in root_EQ.iter(cim+'ConnectivityNode'):
        connectivity_node_list.append(ConnectivityNode(connectivity_node_xml.get(rdf+'ID'), 
        connectivity_node_xml.find(cim+'IdentifiedObject.name').text, 
        connectivity_node_xml.find(cim+"ConnectivityNode.ConnectivityNodeContainer").get(rdf+"resource").replace('#', '')))

    #Forming the list of Energy Consumers
    for energy_consumer_xml in root_EQ.iter(cim+'EnergyConsumer'):
        energy_consumer_list.append(EnergyConsumer(energy_consumer_xml.get(rdf+'ID'), 
        energy_consumer_xml.find(cim+'IdentifiedObject.name').text,
        energy_consumer_xml.find(cim+'Equipment.EquipmentContainer').get(rdf+'resource').replace('#', ''), 
        "", ""))

    i = 0
    for energy_consumer_xml in root_SSH.iter(cim+"EnergyConsumer"):
        energy_consumer_list[i].p=energy_consumer_xml.find(cim+"EnergyConsumer.p").text 
        energy_consumer_list[i].q=energy_consumer_xml.find(cim+"EnergyConsumer.q").text
        i += 1

    #Forming the list of Generating Units
    for generating_unit_xml in root_EQ.iter(cim+'GeneratingUnit'):
        generating_unit_list.append(GeneratingUnit(generating_unit_xml.get(rdf+'ID'), 
        generating_unit_xml.find(cim+'IdentifiedObject.name').text, 
        generating_unit_xml.find(cim+"GeneratingUnit.initialP").text,
        generating_unit_xml.find(cim+"GeneratingUnit.nominalP").text,
        generating_unit_xml.find(cim+'GeneratingUnit.maxOperatingP').text, 
        generating_unit_xml.find(cim+'GeneratingUnit.minOperatingP').text,
        generating_unit_xml.find(cim+'Equipment.EquipmentContainer').get(rdf+'resource').replace('#', ''))) 

    #Forming the list of Power Transformers
    for power_transformer_xml in root_EQ.iter(cim+'PowerTransformer'):
        power_transformer_list.append(PowerTransformer(power_transformer_xml.get(rdf+'ID'), 
        power_transformer_xml.find(cim+'IdentifiedObject.name').text,
        power_transformer_xml.find(cim+'Equipment.EquipmentContainer').get(rdf+'resource').replace('#', '')))

    #Forming the list of Power Transfoemrs Ends
    for power_transformer_end_xml in root_EQ.iter(cim+'PowerTransformerEnd'):
        power_transformer_end_list.append(PowerTransformerEnd(power_transformer_end_xml.get(rdf+'ID'),
        power_transformer_end_xml.find(cim+'IdentifiedObject.name').text, 
        power_transformer_end_xml.find(cim+'PowerTransformerEnd.r').text,
        power_transformer_end_xml.find(cim+'PowerTransformerEnd.x').text,
        power_transformer_end_xml.find(cim+'PowerTransformerEnd.b').text,
        power_transformer_end_xml.find(cim+'PowerTransformerEnd.g').text,
        power_transformer_end_xml.find(cim+'PowerTransformerEnd.r0').text,
        power_transformer_end_xml.find(cim+'PowerTransformerEnd.x0').text,
        power_transformer_end_xml.find(cim+'PowerTransformerEnd.b0').text,
        power_transformer_end_xml.find(cim+'PowerTransformerEnd.g0').text,
        power_transformer_end_xml.find(cim+'TransformerEnd.rground').text,
        power_transformer_end_xml.find(cim+'TransformerEnd.xground').text,
        power_transformer_end_xml.find(cim+'PowerTransformerEnd.ratedS').text,
        power_transformer_end_xml.find(cim+'PowerTransformerEnd.ratedU').text,
        power_transformer_end_xml.find(cim+'PowerTransformerEnd.phaseAngleClock').text,
        power_transformer_end_xml.find(cim+'PowerTransformerEnd.connectionKind').get(rdf+'resource'),
        power_transformer_end_xml.find(cim+'TransformerEnd.BaseVoltage').get(rdf+'resource').replace('#', ''),
        power_transformer_end_xml.find(cim+'PowerTransformerEnd.PowerTransformer').get(rdf+'resource').replace('#', ''), 
        power_transformer_end_xml.find(cim+'TransformerEnd.Terminal').get(rdf+'resource').replace('#', '')))

    #Forming the list of Synchronous Machines
    for synchronous_machine_xml in root_EQ.iter(cim+'SynchronousMachine'):
        synchronous_machine_list.append(SynchronousMachine(synchronous_machine_xml.get(rdf+'ID'), 
        synchronous_machine_xml.find(cim+'IdentifiedObject.name').text,
        synchronous_machine_xml.find(cim+'RotatingMachine.GeneratingUnit').get(rdf+'resource').replace('#', ''),
        synchronous_machine_xml.find(cim+'Equipment.EquipmentContainer').get(rdf+'resource').replace('#', '')))

    i = 0
    for synchronous_machine_xml in root_SSH.iter(cim+'SynchronousMachine'):
        synchronous_machine_list[i].active_power = synchronous_machine_xml.find(cim+'RotatingMachine.p').text
        i += 1
        
    #Forming the list of Terminals
    for terminal_xml in root_EQ.iter(cim+'Terminal'):
        terminal_list.append(Terminal(terminal_xml.get(rdf+'ID'), 
        terminal_xml.find(cim+'IdentifiedObject.name').text,
        terminal_xml.find(cim+'Terminal.ConnectivityNode').get(rdf+'resource').replace('#', ''),       
        terminal_xml.find(cim+'Terminal.ConductingEquipment').get(rdf+'resource').replace('#', '')))  
        
    #Forming the list of Voltage Levels
    for voltage_level_xml in root_EQ.iter(cim+'VoltageLevel'):
        voltage_level_list.append(VoltageLevel(voltage_level_xml.get(rdf+'ID'), 
        voltage_level_xml.find(cim+'IdentifiedObject.name').text,
        voltage_level_xml.find(cim+'VoltageLevel.BaseVoltage').get(rdf+'resource').replace('#', ''))                                 )
 
    return (AC_line_segment_list, breaker_list, busbar_section_list, connectivity_node_list, 
            energy_consumer_list, generating_unit_list, power_transformer_list, power_transformer_end_list, 
            synchronous_machine_list, terminal_list, voltage_level_list)

# Call the function to extract grid topology for both BE and NL configurations
(AC_line_segment_BE, breaker_BE, busbar_section_BE, connectivity_node_BE, 
 energy_consumer_BE, generating_unit_BE, power_transformer_BE, power_transformer_end_BE,
 synchronous_machine_BE, terminal_BE, voltage_level_BE) = extract_grid_topology(root_BE_EQ, root_BE_SSH)

(AC_line_segment_NL, breaker_NL, busbar_section_NL, connectivity_node_NL, 
 energy_consumer_NL, generating_unit_NL, power_transformer_NL, power_transformer_end_NL,
 synchronous_machine_NL, terminal_NL, voltage_level_NL) = extract_grid_topology(root_NL_EQ, root_NL_SSH)
       
# Find the missing resource IDs in each CIM file
terminal_BE_id = []
terminal_NL_id = []
connectivity_BE_id = []
connectivity_NL_id = []

for i in range(len(terminal_BE)):
    terminal_BE_id.append(terminal_BE[i].ConnectivityNode)
for i in range(len(terminal_NL)):
    terminal_NL_id.append(terminal_NL[i].ConnectivityNode)
for i in range(len(connectivity_node_BE)):
    connectivity_BE_id.append(connectivity_node_BE[i].ID)
for i in range(len(connectivity_node_NL)):
    connectivity_NL_id.append(connectivity_node_NL[i].ID)

missing_cn_be = [id for id in terminal_BE_id if id not in connectivity_BE_id]
missing_cn_nl = [id for id in terminal_NL_id if id not in connectivity_NL_id]

common_ids = list(set(missing_cn_be) & set(missing_cn_nl))

print(common_ids)

# Create dictionaries for indexing the IDs
Terminal_dict_BE = {}
for i in range(len(terminal_BE)):
    Terminal_dict_BE[terminal_BE[i].id] = i 

Terminal_dict_NL = {}
for i in range(len(terminal_NL)):
    Terminal_dict_NL[terminal_NL[i].id] = i 
    
ConnectivityNode_dict = {}
connectivity_node_all = connectivity_BE_id + connectivity_NL_id + common_ids
for i in range(len(connectivity_node_all)):
    ConnectivityNode_dict[connectivity_node_all[i]] = i

VoltageLevel_dict_BE = {}
for i in range(len(voltage_level_BE)):
    VoltageLevel_dict_BE[voltage_level_BE[i].id] = i 
    
VoltageLevel_dict_NL = {}
for i in range(len(voltage_level_NL)):
    VoltageLevel_dict_NL[voltage_level_NL[i].id] = i 

# Network Traversing
    
# Define function to find the busbar for connectivity node attached to terminal

def find_busbar_for_connectivity_node_BE(CN_id):
    type_cn = 'n'
    for i in range(len(terminal_BE)):
        if CN_id == terminal_BE[i].ConnectivityNode:
            for j in range(len(busbar_section_BE)):
                if terminal_BE[i].ConductingEquipment == busbar_section_BE[j].id:
                    type_cn ='b'
    return type_cn

def find_busbar_for_connectivity_node_NL(CN_id):
    type_cn = 'n'
    for i in range(len(terminal_NL)):
        if CN_id == terminal_NL[i].ConnectivityNode:
            for j in range(len(busbar_section_NL)):
                if terminal_NL[i].ConductingEquipment == busbar_section_NL[j].id:
                    type_cn ='b'
    return type_cn
    
#Traversal for each equipment

# Create lists of connectivity nodes for BE and NL configurations
def create_connectivitynode_list(connectivity_nodes, voltage_level_dict, voltage_levels, find_busbar_func):
    connectivitynode_list = []

    for node in connectivity_nodes:
        name = node.name
        container = node.connectivity_node_container
        voltage_level = float(voltage_levels[voltage_level_dict[container]].name)
        busbar = find_busbar_func(node.ID)

        connectivitynode_list.append([name, voltage_level, busbar])

    return connectivitynode_list


connectivitynode_BE_list = create_connectivitynode_list(connectivity_node_BE, 
                                                           VoltageLevel_dict_BE, 
                                                           voltage_level_BE, 
                                                           find_busbar_for_connectivity_node_BE)
connectivitynode_NL_list = create_connectivitynode_list(connectivity_node_NL, 
                                                           VoltageLevel_dict_NL, 
                                                           voltage_level_NL, 
                                                           find_busbar_for_connectivity_node_NL)
# Add common IDs to the list
connectivitynode_common_list = []
for common_id in common_ids:
    connectivitynode_common_list.append([common_id, '380.0', 'n'])


## Create lists of Power transformers for BE and NL configurations 
def create_power_transformer_list(power_transformers, power_transformer_ends, Voltage_level, VoltageLevel_dict, 
                                  connectivitynode, terminal, Terminal_dict, ConnectivityNode_dict):
    power_transformer_list = []

    for i in range(len(power_transformers)):
        transformer_info = [0 for _ in range(8)]
        transformer_info[0] = power_transformers[i].name
        transformer_info[7] = 'two_winding'

        terminal_PT = []
        voltage_PT_1 = set()
        connectivitynode_PT = []

        for j in range(len(power_transformer_ends)):
            if power_transformers[i].id == power_transformer_ends[j].PowerTransformer:
                terminal_PT.append(Terminal_dict[power_transformer_ends[j].Terminal])
                connectivitynode_PT.append(ConnectivityNode_dict[terminal[terminal_PT[-1]].ConnectivityNode])
                for k in range(len(Voltage_level)):
                               if power_transformer_ends[j].BaseVoltage == Voltage_level[k].BaseVoltage:
                                   voltage_PT_1.add(float(Voltage_level[k].name))
        voltage_PT = list(voltage_PT_1)
        min_voltage_index = voltage_PT.index(min(voltage_PT))
        max_voltage_index = voltage_PT.index(max(voltage_PT))

        transformer_info[1] = connectivitynode_PT[min_voltage_index]
        transformer_info[4] = voltage_PT[min_voltage_index]
        transformer_info[3] = connectivitynode_PT[max_voltage_index]
        transformer_info[6] = voltage_PT[max_voltage_index]

        if len(connectivitynode_PT) == 3:
            transformer_info[2] = connectivitynode_PT[3 - (min_voltage_index + max_voltage_index)]
            transformer_info[5] = voltage_PT[3 - (min_voltage_index + max_voltage_index)]
            transformer_info[7] = 'three_winding'

        power_transformer_list.append(transformer_info)

    return power_transformer_list

power_transformer_NL_list = create_power_transformer_list(
    power_transformer_NL, power_transformer_end_NL, voltage_level_NL , VoltageLevel_dict_NL,
    connectivitynode_NL_list, terminal_NL, Terminal_dict_NL, ConnectivityNode_dict
)
power_transformer_BE_list = create_power_transformer_list(
    power_transformer_BE, power_transformer_end_BE, voltage_level_BE, VoltageLevel_dict_BE, 
    connectivitynode_BE_list, terminal_BE, Terminal_dict_BE, ConnectivityNode_dict
)

power_transformer_list = power_transformer_NL_list + power_transformer_BE_list

# Create lists of AC line segments for BE and NL configurations
def create_ac_line_segment_list(AC_line_segment, terminal, connectivity_node):
    acline_segment_list = []

    for segment in AC_line_segment:
        name = segment.name
        length = float(segment.length)

        connectivity_nodes = []
        count = 0

        for i in range(len(terminal)):
            if segment.id == terminal[i].ConductingEquipment:
                count += 1
                if count == 1:
                    connectivity_nodes.append(ConnectivityNode_dict[terminal[i].ConnectivityNode])
                else:
                    connectivity_nodes.append(ConnectivityNode_dict[terminal[i].ConnectivityNode])

        # Ensure that the list has at least two connectivity nodes for each AC line segment
        while len(connectivity_nodes) < 2:
            connectivity_nodes.append(None)

        acline_segment_list.append([name, connectivity_nodes[0], connectivity_nodes[1], length])

    return acline_segment_list

aclinesegment_BE_list = create_ac_line_segment_list(AC_line_segment_BE, terminal_BE, connectivity_node_BE)
aclinesegment_NL_list = create_ac_line_segment_list(AC_line_segment_NL, terminal_NL, connectivity_node_NL)
aclinesegment_list = aclinesegment_BE_list + aclinesegment_NL_list

# Create lists of breakers for BE and NL configurations
def create_breaker_list(breaker, terminal, ConnectivityNode_dict):
    Breaker_t_list = []

    for breaker in breaker:
        name = breaker.name
        state = breaker.state == 'false'
        connectivity_nodes = [None, None]

        count = 0
        for i in range(len(terminal)):
            if breaker.id == terminal[i].ConductingEquipment:
                count += 1
                if count == 1:
                    connectivity_nodes[0] = ConnectivityNode_dict[terminal[i].ConnectivityNode]
                else:
                    connectivity_nodes[1] = ConnectivityNode_dict[terminal[i].ConnectivityNode]

        Breaker_t_list.append([name, connectivity_nodes[0], connectivity_nodes[1], state])

    return Breaker_t_list

breaker_BE_list = create_breaker_list(breaker_BE, terminal_BE, ConnectivityNode_dict)
breaker_NL_list = create_breaker_list(breaker_NL, terminal_NL, ConnectivityNode_dict)
breaker_list = breaker_BE_list + breaker_NL_list

# Create lists of energy consumers for BE and NL configurations
def create_energy_consumer_list(energy_consumers, terminal, ConnectivityNode_dict):
    energy_consumer_list = []

    for i in range(len(energy_consumers)):
        name = energy_consumers[i].name
        p = energy_consumers[i].p
        q = energy_consumers[i].q

        # Find corresponding terminal
        for j in range(len(terminal)):
            if energy_consumers[i].id == terminal[j].ConductingEquipment:
                connectivity_node = ConnectivityNode_dict[terminal[j].ConnectivityNode]
        energy_consumer_list.append([name, p, q, connectivity_node])
    
    return energy_consumer_list


energyconsumer_BE_list = create_energy_consumer_list(energy_consumer_BE, terminal_BE, ConnectivityNode_dict)
energyconsumer_NL_list = create_energy_consumer_list(energy_consumer_NL, terminal_NL, ConnectivityNode_dict)
energyconsumer_list = energyconsumer_BE_list + energyconsumer_NL_list


# Create lists of generators for BE and NL configurations
def create_generator_list(synchronous_machine, generating_unit, terminal, ConnectivityNode_dict):
    Generator_list= []

    for i in range(len(generating_unit)):
        name = generating_unit[i].name
        p = generating_unit[i].nominalP

        for k in range(len(synchronous_machine)):
            if generating_unit[i].id == synchronous_machine[k].GeneratingUnit:
                for j in range(len(terminal)):
                    if synchronous_machine[k].id == terminal[j].ConductingEquipment:
                        connectivity_node = ConnectivityNode_dict[terminal[j].ConnectivityNode]
        Generator_list.append([name, p, connectivity_node])
        
    return Generator_list

generator_BE_list = create_generator_list(synchronous_machine_BE, generating_unit_BE, terminal_BE, ConnectivityNode_dict)
generator_NL_list = create_generator_list(synchronous_machine_NL, generating_unit_NL, terminal_NL, ConnectivityNode_dict)
generator_list = generator_BE_list + generator_NL_list


# Create lists of Synchronous Machines for BE and NL configurations
def create_synchronousmachine_list(synchronous_machines, terminals, ConnectivityNode_dict):
    synchronousmachine_list = []

    for i in range(len(synchronous_machines)):
        name = synchronous_machines[i].name
        active_power = synchronous_machines[i].active_power
        connectivity_node = None

        for j in range(len(terminals)):
            if synchronous_machines[i].id == terminals[j].ConductingEquipment:
                connectivity_node = ConnectivityNode_dict[terminals[j].ConnectivityNode]
                break

        synchronousmachine_list.append([name, active_power, connectivity_node])

    return synchronousmachine_list

synchronousmachine_BE_list = create_synchronousmachine_list(synchronous_machine_BE, terminal_BE, ConnectivityNode_dict)
synchronousmachine_NL_list = create_synchronousmachine_list(synchronous_machine_NL, terminal_NL, ConnectivityNode_dict)
synchronousmachine_list = synchronousmachine_BE_list + synchronousmachine_NL_list

#Create network in Pandapower.

#create component for panda power
net = pp.create_empty_network()

# create busbar 'b' and node 'n'
for i in range (len(connectivitynode_BE_list)):
    pp.create_bus(net, name=connectivitynode_BE_list[i][0], vn_kv=connectivitynode_BE_list[i][1], type = connectivitynode_BE_list[i][2])


for i in range (len(connectivitynode_NL_list)):
    pp.create_bus(net, name=connectivitynode_NL_list[i][0], vn_kv=connectivitynode_NL_list[i][1], type = connectivitynode_NL_list[i][2])

for i in range (len(connectivitynode_common_list)):
    pp.create_bus(net, name=connectivitynode_common_list[i][0], vn_kv=connectivitynode_common_list[i][1] , type= connectivitynode_common_list[i][2])

print(net.bus)

#Transformers
for i in range (len(power_transformer_list)):
    if power_transformer_list[i][7] == 'two_winding':
        pp.create_transformer(net, power_transformer_list[i][3], power_transformer_list[i][1], name = power_transformer_list[i][0], std_type="25 MVA 110/20 kV")
    if power_transformer_list[i][7] == 'three_winding':
        pp.create_transformer3w(net, power_transformer_list[i][3], power_transformer_list[i][2], power_transformer_list[i][1], name = power_transformer_list[i][0], std_type="63/25/38 MVA 110/20/10 kV")

#Breakers
for i in range (len(breaker_list)):
    pp.create_switch(net, breaker_list[i][1], breaker_list[i][2], et="b", type="CB", closed = breaker_list[i][3])

print(net.switch)

#Load
for i in range (len(energyconsumer_list)):
    pp.create_load(net, energyconsumer_list[i][3], p_mw = energyconsumer_list[i][1], q_mvar = energyconsumer_list[i][2], name = energyconsumer_list[i][0])

print(net.load)

#Generator 
for i in range (len(generator_list)):
    pp.create_sgen(net, generator_list[i][2], p_mw = generator_list[i][1], name = generator_list[i][0])

print(net.sgen)

#Lines
for i in range (len(aclinesegment_list)):
    pp.create_line(net, from_bus = aclinesegment_list[i][1], to_bus = aclinesegment_list[i][2], length_km = aclinesegment_list[i][3], std_type = "N2XS(FL)2Y 1x300 RM/35 64/110 kV",  name = aclinesegment_list[i][0])

print(net.line)

#synchronous machine
for i in range (len(synchronousmachine_list)):
    pp.create_sgen(net, synchronousmachine_list[i][2], p_mw = synchronousmachine_list[i][1], name = synchronousmachine_list[i][0])
print(net.sgen)

print(net)

# plot the network
plot.simple_plot (net, line_width=3.0, bus_size=1.0, ext_grid_size=1.0,
                        trafo_size=1.0, plot_loads=True, plot_sgens=True, 
                        load_size=2.0, sgen_size=2.5, switch_size=1.0, 
                        switch_distance=1.0, plot_line_switches=True, 
                        scale_size=True, 
                        bus_color=['red' if net.bus.at[i, 'type'] == 'b' else 'blue' for i in net.bus.index], 
                        line_color='black', trafo_color='green', switch_color='k', 
                        library='igraph', show_plot=True, ax=None)
