# -*- coding: utf-8 -*-
class Breaker:
    def __init__(self, id, name, EquipmentContainer, state):
        self.id = id
        self.name = name
        self.EquipmentContainer = EquipmentContainer
        self.state = state
