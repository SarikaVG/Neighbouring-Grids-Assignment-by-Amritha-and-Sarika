# -*- coding: utf-8 -*-
class GeneratingUnit:
    def __init__(self, id, name, initialP, nominalP, maxOperatingP, minOperatingP, EquipmentContainer):
        self.id = id
        self.name = name
        self.initialP = initialP
        self.nominalP = nominalP
        self.maxOperatingP = maxOperatingP
        self.minOperatingP = minOperatingP       
        self.EquipmentContainer = EquipmentContainer