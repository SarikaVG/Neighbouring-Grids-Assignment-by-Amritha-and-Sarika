# -*- coding: utf-8 -*-
class LinearShuntCompensator:
    def __init__(self, id, name, nomU, b, g, b0, g0, EquipmentContainer):
        self.id = id
        self.name = name
        self.nomU= nomU
        self.b=b
        self.g=g
        self.b0=b0
        self.g0=g0
        self.EquipmentContainer = EquipmentContainer