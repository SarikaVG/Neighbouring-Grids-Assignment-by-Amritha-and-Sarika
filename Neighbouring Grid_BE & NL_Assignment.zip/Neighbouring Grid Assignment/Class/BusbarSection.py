# -*- coding: utf-8 -*-

class BusbarSection:
    def __init__(self, id, name, equipment_container):
        self.id = id
        self.name = name
        self.equipment_container = equipment_container

    
