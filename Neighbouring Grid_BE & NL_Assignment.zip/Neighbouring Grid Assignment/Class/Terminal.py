# -*- coding: utf-8 -*-

class Terminal:
    def __init__(self, id, name, ConnectivityNode, ConductingEquipment):
        self.id = id
        self.name = name
        self.ConnectivityNode = ConnectivityNode
        self.ConductingEquipment = ConductingEquipment
    