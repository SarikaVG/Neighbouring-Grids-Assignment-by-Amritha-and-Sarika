# -*- coding: utf-8 -*-
class SynchronousMachine:
    def __init__(self, id, name, GeneratingUnit, ratedU):
        self.id = id
        self.name = name
        self.GeneratingUnit = GeneratingUnit
        self.ratedU = ratedU

