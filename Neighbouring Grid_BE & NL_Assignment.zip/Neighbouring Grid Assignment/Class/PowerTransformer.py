# -*- coding: utf-8 -*-
class PowerTransformer:
    def __init__(self, id, name, EquipmentContainer):
        self.id = id
        self.name = name
        self.EquipmentContainer = EquipmentContainer
        