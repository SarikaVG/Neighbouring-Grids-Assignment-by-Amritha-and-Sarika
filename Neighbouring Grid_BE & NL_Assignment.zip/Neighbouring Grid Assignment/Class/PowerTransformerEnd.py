class PowerTransformerEnd:
    def __init__(self, id, name, r, x, b, g, r0, x0, b0, g0, 
                 rground, xground, ratedS, ratedU,phaseAngleClock, 
                 connectionKind, BaseVoltage, PowerTransformer, Terminal):
        self.id = id
        self.name = name
        self.r = r
        self.x = x
        self.b = b
        self.g = g
        self.r0 = r0 
        self.x0 = x0
        self.b0 = b0
        self.g0 = g0
        self.rground = rground
        self.xground = xground
        self.ratedS = ratedS
        self.ratedU = ratedU
        self.phaseAngleClock = phaseAngleClock
        self.connectionKind = connectionKind
        self.BaseVoltage = BaseVoltage
        self.PowerTransformer = PowerTransformer
        self.Terminal = Terminal
 