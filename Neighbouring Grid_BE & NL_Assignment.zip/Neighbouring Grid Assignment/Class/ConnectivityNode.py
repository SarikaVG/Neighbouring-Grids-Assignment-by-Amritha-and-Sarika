# -*- coding: utf-8 -*-
class ConnectivityNode:
    def __init__(self, ID, name, connectivity_node_container):
        self.ID = ID
        self.name = name
        self.connectivity_node_container = connectivity_node_container
    

