# -*- coding: utf-8 -*-
class VoltageLevel:
    def __init__(self, id, name, BaseVoltage):
        self.id = id
        self.name= name
        self.BaseVoltage = BaseVoltage
