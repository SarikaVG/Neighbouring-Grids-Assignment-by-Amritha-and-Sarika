# -*- coding: utf-8 -*-
class EnergyConsumer:
    def __init__(self, id, name, EquipmentContainer, p, q):
        self.id = id
        self.name = name
        self.EquipmentContainer = EquipmentContainer
        self.p=p
        self.q=q

    