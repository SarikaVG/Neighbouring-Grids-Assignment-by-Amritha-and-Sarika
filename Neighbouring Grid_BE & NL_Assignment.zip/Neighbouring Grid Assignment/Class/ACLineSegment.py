# -*- coding: utf-8 -*-

class ACLineSegment:
    def __init__(self, id, name, EquipmentContainer, r,
                 x, bch, length, gch, base_voltage, r0, x0, b0ch, 
                 g0ch):
        self.id = id
        self.name = name
        self.EquipmentContainer = EquipmentContainer
        self.r = r
        self.x = x
        self.bch = bch
        self.length = length
        self.gch = gch
        self.base_voltage = base_voltage
        self.r0 = r0
        self.x0 = x0
        self.b0ch = b0ch
        self.g0ch = g0ch